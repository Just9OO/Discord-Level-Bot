/**
 * Voice XP is tracked by storing when users join voice.
 * A recurring interval awards XP every minute to all users in voice.
 * This event handles joining/leaving to start/stop tracking.
 */

// Map<guildId, Map<userId, joinTimestamp>>
const voiceUsers = new Map();

// Interval handle (one per bot process)
let intervalStarted = false;

module.exports = {
  name: 'voiceStateUpdate',

  execute(oldState, newState, client) {
    const userId  = newState.id;
    const guildId = newState.guild.id;

    const wasInVoice = oldState.channelId && !oldState.selfMute && !oldState.selfDeaf && !oldState.serverMute;
    const isInVoice  = newState.channelId && !newState.selfMute && !newState.selfDeaf && !newState.serverMute;

    if (!voiceUsers.has(guildId)) voiceUsers.set(guildId, new Map());
    const guildMap = voiceUsers.get(guildId);

    if (!wasInVoice && isInVoice) {
      // Joined valid voice state
      guildMap.set(userId, Date.now());
    } else if (wasInVoice && !isInVoice) {
      // Left voice / muted / deafened
      guildMap.delete(userId);
    } else if (wasInVoice && isInVoice && oldState.channelId !== newState.channelId) {
      // Switched channel — keep timer running
    } else if (!wasInVoice && !isInVoice) {
      // Might be a mute/deafen event with no channel
      guildMap.delete(userId);
    }

    // Ensure the XP ticker is running
    if (!intervalStarted) {
      intervalStarted = true;
      startVoiceTicker(client);
    }
  },

  // Exposed so index.js can pre-populate on ready
  voiceUsers,
};

function startVoiceTicker(client) {
  const { getUser, saveUser, getGuild, levelFromXp, getRank } = require('../database/db');
  const { generateLevelCard } = require('../utils/cardRenderer');
  const { AttachmentBuilder } = require('discord.js');

  // Award voice XP every 60 seconds
  setInterval(async () => {
    for (const [guildId, guildMap] of voiceUsers) {
      if (guildMap.size === 0) continue;

      let settings;
      try { settings = getGuild(guildId); } catch { continue; }

      for (const [userId] of guildMap) {
        try {
          const userData = getUser(guildId, userId);
          const earned   = Math.floor(settings.voice_xp_rate * settings.xp_multiplier);

          const oldLevel = userData.voice_level;
          const newXp    = userData.voice_xp + earned;
          const newLevel = levelFromXp(newXp);

          userData.voice_xp    = newXp;
          userData.voice_level = newLevel;
          saveUser(userData);

          if (newLevel > oldLevel) {
            // Fire level-up card
            await sendVoiceLevelUp(guildId, userId, newLevel, settings, client);
          }
        } catch (err) {
          console.error('[VoiceXP] Error awarding XP:', err);
        }
      }
    }
  }, 60_000);
}

async function sendVoiceLevelUp(guildId, userId, newLevel, settings, client) {
  try {
    const { getUser, getRank } = require('../database/db');
    const { generateLevelCard } = require('../utils/cardRenderer');
    const { AttachmentBuilder } = require('discord.js');

    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;

    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;

    const userData  = getUser(guildId, userId);
    const textRank  = getRank(guildId, userId, 'text');
    const voiceRank = getRank(guildId, userId, 'voice');

    const buffer = await generateLevelCard({
      username: member.user.username,
      discriminator: member.user.discriminator,
      avatarUrl: member.user.displayAvatarURL({ extension: 'png', size: 256 }),
      textXp:   userData.text_xp,
      voiceXp:  userData.voice_xp,
      textLevel: userData.text_level,
      voiceLevel: userData.voice_level,
      textRank, voiceRank,
      guildSettings: settings,
    });

    const attachment = new AttachmentBuilder(buffer, { name: 'levelup.png' });
    const content = `🎉 <@${userId}> leveled up! **🎙️ Voice Level ${newLevel}** reached!`;

    const channelId = settings.levelup_channel;
    if (channelId) {
      const channel = client.channels.cache.get(channelId) ||
        await client.channels.fetch(channelId).catch(() => null);
      if (channel) return channel.send({ content, files: [attachment] });
    }

    // Fallback: DM the user
    member.send({ content, files: [attachment] }).catch(() => {});
  } catch (err) {
    console.error('[VoiceLevelUp] Failed:', err);
  }
}
