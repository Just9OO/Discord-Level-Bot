const { AttachmentBuilder } = require('discord.js');
const {
  getUser, saveUser, getGuild,
  levelFromXp, xpForLevel,
} = require('../database/db');
const { generateLevelCard } = require('../utils/cardRenderer');

const COOLDOWN_MS = 60_000; // 1 minute between XP gains
const MIN_LENGTH  = 5;      // Minimum message length to earn XP

module.exports = {
  name: 'messageCreate',

  async execute(message, client) {
    // Ignore bots, DMs, system messages
    if (message.author.bot || !message.guild || message.system) return;

    // Ignore very short messages (anti-spam)
    if (message.content.length < MIN_LENGTH) return;

    const guildId  = message.guild.id;
    const userId   = message.author.id;
    const settings = getGuild(guildId);

    // Check if channel is ignored
    const ignoredChannels = JSON.parse(settings.ignored_channels || '[]');
    if (ignoredChannels.includes(message.channel.id)) return;

    // Check if user has a no-XP role
    const noXpRoles = JSON.parse(settings.no_xp_roles || '[]');
    const member    = message.member || await message.guild.members.fetch(userId).catch(() => null);
    if (member && noXpRoles.some(r => member.roles.cache.has(r))) return;

    const userData = getUser(guildId, userId);
    const now      = Date.now();

    // Cooldown check (anti-spam: one XP grant per minute)
    if (now - userData.last_message < COOLDOWN_MS) return;

    // Random XP in configured range × multiplier
    const base = settings.text_xp_min +
      Math.floor(Math.random() * (settings.text_xp_max - settings.text_xp_min + 1));
    const earned = Math.floor(base * settings.xp_multiplier);

    const oldLevel = userData.text_level;
    const newXp    = userData.text_xp + earned;
    const newLevel = levelFromXp(newXp);

    userData.text_xp     = newXp;
    userData.text_level  = newLevel;
    userData.last_message = now;
    saveUser(userData);

    // Level-up announcement
    if (newLevel > oldLevel) {
      await sendLevelUp(message, member || message.author, newLevel, 'text', settings, client);
    }
  },
};

async function sendLevelUp(message, memberOrUser, newLevel, type, settings, client) {
  const channelId = settings.levelup_channel;

  // Build a small level-up embed + card
  try {
    const user = memberOrUser.user || memberOrUser;
    const userData = getUser(message.guild.id, user.id);
    const { getRank } = require('../database/db');
    const textRank  = getRank(message.guild.id, user.id, 'text');
    const voiceRank = getRank(message.guild.id, user.id, 'voice');

    const buffer = await generateLevelCard({
      username: user.username,
      discriminator: user.discriminator,
      avatarUrl: user.displayAvatarURL({ extension: 'png', size: 256 }),
      textXp:   userData.text_xp,
      voiceXp:  userData.voice_xp,
      textLevel: userData.text_level,
      voiceLevel: userData.voice_level,
      textRank, voiceRank,
      guildSettings: settings,
    });

    const attachment = new AttachmentBuilder(buffer, { name: 'levelup.png' });
    const content = `🎉 <@${user.id}> leveled up! **${type === 'voice' ? '🎙️ Voice' : '💬 Text'} Level ${newLevel}** reached!`;

    if (channelId) {
      const channel = client.channels.cache.get(channelId) ||
        await client.channels.fetch(channelId).catch(() => null);
      if (channel) {
        return channel.send({ content, files: [attachment] });
      }
    }

    // Fallback: send in the same channel if no announcement channel set
    message.channel.send({ content, files: [attachment] }).catch(() => {});
  } catch (err) {
    console.error('[LevelUp] Failed to send level-up message:', err);
  }
}
