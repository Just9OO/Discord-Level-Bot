const { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder } = require('discord.js');
const { getLeaderboard, getGuild } = require('../database/db');
const { generateLeaderboardCard } = require('../utils/cardRenderer');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the server leaderboard')
    .addStringOption(opt =>
      opt.setName('type')
        .setDescription('Text or Voice leaderboard')
        .setRequired(true)
        .addChoices(
          { name: '💬 Text', value: 'text' },
          { name: '🎙️ Voice', value: 'voice' },
        )
    )
    .addStringOption(opt =>
      opt.setName('duration')
        .setDescription('Time period (currently Lifetime is supported; more coming soon)')
        .setRequired(false)
        .addChoices(
          { name: '📅 Day',      value: 'day' },
          { name: '📆 Week',     value: 'week' },
          { name: '🗓️ Month',    value: 'month' },
          { name: '🏆 Lifetime', value: 'lifetime' },
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();

    const type     = interaction.options.getString('type');
    const duration = interaction.options.getString('duration') || 'lifetime';
    const guildId  = interaction.guildId;
    const guildSettings = getGuild(guildId);

    let entries = getLeaderboard(guildId, type);

    // Enrich entries with display tags
    for (const entry of entries) {
      try {
        const member = await interaction.guild.members.fetch(entry.user_id).catch(() => null);
        entry.tag = member?.displayName || `User ${entry.user_id.slice(-4)}`;
        entry.avatarUrl = member?.user.displayAvatarURL({ extension: 'png', size: 64 });
      } catch {
        entry.tag = `User ${entry.user_id.slice(-4)}`;
      }
    }

    if (entries.length === 0) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(guildSettings.card_color || '#5865F2')
            .setTitle('Leaderboard empty')
            .setDescription('No one has earned any XP yet! Start chatting to gain levels.'),
        ],
      });
    }

    const buffer = await generateLeaderboardCard(entries, type, guildSettings);
    const attachment = new AttachmentBuilder(buffer, { name: 'leaderboard.png' });

    const durationLabel = {
      day: 'Today', week: 'This Week', month: 'This Month', lifetime: 'All Time',
    }[duration] || 'All Time';

    await interaction.editReply({
      content: `**${durationLabel} ${type === 'voice' ? '🎙️ Voice' : '💬 Text'} Leaderboard**`,
      files: [attachment],
    });
  },
};
