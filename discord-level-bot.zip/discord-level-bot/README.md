# 🎮 Discord Level Bot

A feature-rich levelling bot with **Text XP**, **Voice XP**, beautiful Arcane-style level cards, leaderboards, and full admin customisation — ready for any hosting provider.

---

## ✨ Features

| Feature | Details |
|---|---|
| Level Cards | Beautiful canvas-rendered cards with text & voice XP bars, avatar, rank |
| Text XP | Anti-spam (60s cooldown), configurable min/max XP, multiplier |
| Voice XP | Awarded every minute in voice — muted/deafened users don't earn |
| Leaderboard | Top 10 for text or voice, rendered as an image card |
| Level-up Alerts | Sends a card to a configured channel (or falls back to current channel) |
| Card Customisation | Admins can change accent, background, XP bar, and text colors |
| Ignored Channels | Specific channels can be excluded from earning XP |
| No-XP Roles | Specific roles can be excluded from earning XP |
| Admin Only | Admin commands are hidden from non-admins at the Discord level |
| Auto-deploy | Commands are registered every time `index.js` runs — no separate step needed |
| Optimised DB | SQLite with WAL mode, prepared statements, and proper indexes |

---

## 🚀 Setup

### 1. Create a Discord Application

1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Click **New Application** → give it a name
3. Go to **Bot** → click **Add Bot**
4. Under **Privileged Gateway Intents**, enable:
   - **Server Members Intent**
   - **Message Content Intent**
5. Copy your **Bot Token**
6. Go to **OAuth2 → General** and copy your **Client ID**

### 2. Install the Bot

```bash
git clone <your-repo>
cd discord-level-bot
npm install
```

### 3. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_client_id_here

# Optional: set this to a guild ID during development for instant command updates
# Leave empty for global commands (takes up to 1 hour)
GUILD_ID=

DB_PATH=./data/bot.db
```

### 4. Invite the Bot

Generate an invite URL in **OAuth2 → URL Generator** with scopes:
- `bot`
- `applications.commands`

And bot permissions:
- Send Messages, Embed Links, Attach Files, Read Message History, View Channels
- Connect, View Channel (for voice tracking)

### 5. Run

```bash
npm start
```

Commands are **automatically deployed** on every startup. No separate deploy script needed.

---

## 📋 Commands

### User Commands

| Command | Description |
|---|---|
| `/level [user]` | View your level card (or another user's) |
| `/leaderboard <type> [duration]` | View text or voice leaderboard |
| `/stats` | Server-wide XP statistics |
| `/help` | Show all commands |

### Admin Commands (Administrator permission required)

| Command | Description |
|---|---|
| `/set-xp <user> <type> <level>` | Force-set a user's level (0–100) |
| `/set-channel [channel]` | Set level-up announcement channel |
| `/set-card-color <element> <hex>` | Customize card colors |
| `/set-xp-rate` | Configure XP rates & multiplier |
| `/ignore-channel <channel>` | Toggle XP earning in a channel |
| `/no-xp-role <role>` | Toggle XP earning for a role |
| `/reset-user <user> <type>` | Reset a user's XP |

---

## 🎨 Card Color Elements

| Element | Default | Description |
|---|---|---|
| Accent / Border | `#5865F2` | Left border stripe and avatar ring |
| Background | `#23272A` | Card background |
| XP Bar | `#5865F2` | Text XP bar color |
| Text | `#FFFFFF` | Username and labels |

Voice XP bar automatically shifts hue from the Text bar color.

---

## ⚙️ XP Configuration

- **Text cooldown:** 60 seconds (hardcoded to prevent spam)
- **Default text XP:** 15–25 per message
- **Default voice XP:** 10 per minute
- **Muted/deafened users** do not earn voice XP
- **XP curve:** `XP for level N = floor(100 × (N+1)^1.5)` — exponential, same feel as Arcane

---

## 🏗️ Project Structure

```
discord-level-bot/
├── src/
│   ├── index.js                 # Entry point (auto-deploys commands)
│   ├── commands/
│   │   ├── level.js
│   │   ├── leaderboard.js
│   │   ├── setXp.js
│   │   ├── setChannel.js
│   │   ├── setCardColor.js
│   │   ├── setXpRate.js
│   │   ├── ignoreChannel.js
│   │   ├── noXpRole.js
│   │   ├── resetUser.js
│   │   ├── stats.js
│   │   └── help.js
│   ├── events/
│   │   ├── ready.js
│   │   ├── messageCreate.js
│   │   ├── voiceStateUpdate.js
│   │   └── interactionCreate.js
│   ├── database/
│   │   └── db.js                # SQLite + all DB logic
│   └── utils/
│       ├── cardRenderer.js      # Canvas card generation
│       ├── deployCommands.js    # Slash command registration
│       └── xpHelpers.js         # Utility functions
├── data/                        # Auto-created, holds bot.db
├── assets/fonts/                # Optional — add Montserrat TTFs here
├── .env                         # Your secrets (gitignored)
├── .env.example
└── package.json
```

---

## 🖥️ Hosting

### Railway / Render / Fly.io

Just set the environment variables in the dashboard and deploy. Commands auto-register on startup.

### VPS / Docker

```bash
npm start
# or with pm2:
pm2 start src/index.js --name level-bot
```

### Optional: Add Custom Fonts

Download [Montserrat](https://fonts.google.com/specimen/Montserrat) and place:
- `assets/fonts/Montserrat-Bold.ttf`
- `assets/fonts/Montserrat-Regular.ttf`

The bot falls back to system fonts if these aren't present.

---

## 📜 License

MIT
