require('dotenv').config();
const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const path = require('path');
const fs   = require('fs');
const { deployCommands } = require('./utils/deployCommands');

// ─── Validate environment ─────────────────────────────────────────────────────
const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
if (!DISCORD_TOKEN) throw new Error('Missing DISCORD_TOKEN in .env');
if (!CLIENT_ID)     throw new Error('Missing CLIENT_ID in .env');

// ─── Client setup ─────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Message, Partials.Channel],
});

// ─── Load commands ────────────────────────────────────────────────────────────
client.commands = new Collection();
const commandsDir = path.join(__dirname, 'src/commands');

for (const file of fs.readdirSync(commandsDir).filter(f => f.endsWith('.js'))) {
  const command = require(path.join(commandsDir, file));
  if (!command.data || !command.execute) {
    console.warn(`[Commands] Skipping ${file} — missing data or execute`);
    continue;
  }
  client.commands.set(command.data.name, command);
  console.log(`  📝 Loaded command: /${command.data.name}`);
}

// ─── Load events ──────────────────────────────────────────────────────────────
const eventsDir = path.join(__dirname, 'src/events');

for (const file of fs.readdirSync(eventsDir).filter(f => f.endsWith('.js'))) {
  const event = require(path.join(eventsDir, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
  console.log(`  📡 Loaded event: ${event.name}`);
}

// ─── Graceful shutdown ────────────────────────────────────────────────────────
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

function shutdown(signal) {
  console.log(`\n[${signal}] Shutting down gracefully…`);
  client.destroy();
  process.exit(0);
}

process.on('unhandledRejection', err => {
  console.error('[UnhandledRejection]', err);
});

// ─── Deploy commands then login ───────────────────────────────────────────────
(async () => {
  try {
    // Always deploy on startup so hosting services (Railway, Fly.io, etc.)
    // that don't run a separate deploy step always have up-to-date commands.
    await deployCommands(CLIENT_ID, DISCORD_TOKEN, GUILD_ID || null);
  } catch (err) {
    console.error('Command deploy failed — continuing anyway:', err.message);
  }

  await client.login(DISCORD_TOKEN);
})();
