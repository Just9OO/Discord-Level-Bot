// BUG FIX: moved getRank require to top level — was being required inside sendLevelUp on every call
const { getUser, saveUser, getGuild, levelFromXp, getRank } = require('../database/db');
const { generateLevelCard } = require('../utils/cardRenderer');
const { AttachmentBuilder } = require('discord.js');

const COOLDOWN_MS = 60_000;
const MIN_LENGTH  = 5;

module.exports = {
  name: 'messageCreate',

  async execute(message, client) {
    if (message.author.bot || !message.guild || message.system) return;
    if (message.content.length < MIN_LENGTH) return;

    const guildId  = message.guild.id;
    const userId   = message.author.id;
    const settings = getGuild(guildId);

    const ignoredChannels = JSON.parse(settings.ignored_channels || '[]');
    if (ignoredChannels.includes(message.channel.id)) return;

    const noXpRoles = JSON.parse(settings.no_xp_roles || '[]');
    const member    = message.member || await message.guild.members.fetch(userId).catch(() => null);
    if (member && noXpRoles.some(r => member.roles.cache.has(r))) return;

    const userData = getUser(guildId, userId);
    const now      = Date.now();

    if (now - userData.last_message < COOLDOWN_MS) return;

    const base   = settings.text_xp_min + Math.floor(Math.random() * (settings.text_xp_max - settings.text_xp_min + 1));
    const earned = Math.floor(base * settings.xp_multiplier);

    const oldLevel        = userData.text_level;
    userData.text_xp     += earned;
    userData.text_level   = levelFromXp(userData.text_xp);
    userData.last_message = now;
    saveUser(userData);

    if (userData.text_level > oldLevel) {
      await sendLevelUp(message, member || message.author, userData.text_level, settings, client);
    }
  },
};

async function sendLevelUp(message, memberOrUser, newLevel, settings, client) {
  try {
    const user      = memberOrUser.user || memberOrUser;
    const guildId   = message.guild.id;
    const userData  = getUser(guildId, user.id);
    const textRank  = getRank(guildId, user.id, 'text');
    const voiceRank = getRank(guildId, user.id, 'voice');

    const buffer = await generateLevelCard({
      username:      user.username,
      discriminator: user.discriminator,
      avatarUrl:     user.displayAvatarURL({ extension: 'png', size: 256 }),
      textXp:        userData.text_xp,
      voiceXp:       userData.voice_xp,
      textLevel:     userData.text_level,
      voiceLevel:    userData.voice_level,
      textRank,
      voiceRank,
      guildSettings: settings,
    });

    const attachment = new AttachmentBuilder(buffer, { name: 'levelup.png' });
    const content    = `🎉 <@${user.id}> leveled up! **💬 Text Level ${newLevel}** reached!`;

    const channelId = settings.levelup_channel;
    if (channelId) {
      const channel = client.channels.cache.get(channelId)
        ?? await client.channels.fetch(channelId).catch(() => null);
      if (channel) return channel.send({ content, files: [attachment] });
    }

    message.channel.send({ content, files: [attachment] }).catch(() => {});
  } catch (err) {
    console.error('[LevelUp] Failed to send level-up message:', err);
  }
}
