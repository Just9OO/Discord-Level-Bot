// BUG FIX: moved all requires to top level — they were being re-required inside
// sendVoiceLevelUp on every call, which forces Node to re-resolve the module path
// each time (though it stays cached, it's still unnecessary overhead and bad practice)
const { getUser, saveUser, getGuild, levelFromXp, getRank } = require('../database/db');
const { generateLevelCard } = require('../utils/cardRenderer');
const { AttachmentBuilder } = require('discord.js');

// Map<guildId, Map<userId, joinTimestamp>>
const voiceUsers = new Map();

// Single interval handle — guard so startTicker can only be called once
let tickerInterval = null;

module.exports = {
  name: 'voiceStateUpdate',

  execute(oldState, newState) {
    const userId  = newState.id;
    const guildId = newState.guild.id;

    const wasInVoice = oldState.channelId
      && !oldState.selfMute && !oldState.selfDeaf
      && !oldState.serverMute && !oldState.serverDeaf;

    const isInVoice = newState.channelId
      && !newState.selfMute && !newState.selfDeaf
      && !newState.serverMute && !newState.serverDeaf;

    if (!voiceUsers.has(guildId)) voiceUsers.set(guildId, new Map());
    const guildMap = voiceUsers.get(guildId);

    if (!wasInVoice && isInVoice) {
      // Joined a valid (unmuted) voice state
      guildMap.set(userId, Date.now());
    } else if (wasInVoice && !isInVoice) {
      // Left voice, or muted/deafened themselves or got server-muted/deafened
      guildMap.delete(userId);
    } else if (!wasInVoice && !isInVoice) {
      // Edge case: some state change with no valid voice on either side — ensure removed
      guildMap.delete(userId);
    }
    // wasInVoice && isInVoice (channel switch while unmuted) → keep tracking, no change needed
  },

  // Called once from ready.js after startup population is complete
  startTicker,

  voiceUsers,
};

function startTicker(client) {
  if (tickerInterval) return; // safety guard — only one ticker ever

  tickerInterval = setInterval(async () => {
    for (const [guildId, guildMap] of voiceUsers) {
      if (guildMap.size === 0) continue;

      let settings;
      try {
        settings = getGuild(guildId);
      } catch {
        continue;
      }

      for (const [userId] of guildMap) {
        try {
          const userData = getUser(guildId, userId);
          const earned   = Math.floor(settings.voice_xp_rate * settings.xp_multiplier);

          const oldLevel = userData.voice_level;
          userData.voice_xp    += earned;
          userData.voice_level  = levelFromXp(userData.voice_xp);
          saveUser(userData);

          if (userData.voice_level > oldLevel) {
            await sendVoiceLevelUp(guildId, userId, userData.voice_level, settings, client);
          }
        } catch (err) {
          console.error('[VoiceXP] Error awarding XP to', userId, err);
        }
      }
    }
  }, 60_000);
}

async function sendVoiceLevelUp(guildId, userId, newLevel, settings, client) {
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;

    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;

    const userData  = getUser(guildId, userId);
    const textRank  = getRank(guildId, userId, 'text');
    const voiceRank = getRank(guildId, userId, 'voice');

    const buffer = await generateLevelCard({
      username:      member.user.username,
      discriminator: member.user.discriminator,
      avatarUrl:     member.user.displayAvatarURL({ extension: 'png', size: 256 }),
      textXp:        userData.text_xp,
      voiceXp:       userData.voice_xp,
      textLevel:     userData.text_level,
      voiceLevel:    userData.voice_level,
      textRank,
      voiceRank,
      guildSettings: settings,
    });

    const attachment = new AttachmentBuilder(buffer, { name: 'levelup.png' });
    const content = `🎉 <@${userId}> leveled up! **🎙️ Voice Level ${newLevel}** reached!`;

    const channelId = settings.levelup_channel;
    if (channelId) {
      const channel = client.channels.cache.get(channelId)
        ?? await client.channels.fetch(channelId).catch(() => null);
      if (channel) return channel.send({ content, files: [attachment] });
    }

    // Fallback: DM the user
    member.send({ content, files: [attachment] }).catch(() => {});
  } catch (err) {
    console.error('[VoiceLevelUp] Failed for', userId, err);
  }
}
