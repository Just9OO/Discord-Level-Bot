const Database = require('better-sqlite3');
const path = require('path');
const fs   = require('fs');

const DB_PATH = process.env.DB_PATH || './data/bot.db';
const dbDir   = path.dirname(path.resolve(DB_PATH));

if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.resolve(DB_PATH));

db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('cache_size = -32000');
db.pragma('foreign_keys = ON');

// ─── Schema ───────────────────────────────────────────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    guild_id     TEXT NOT NULL,
    user_id      TEXT NOT NULL,
    text_xp      INTEGER NOT NULL DEFAULT 0,
    voice_xp     INTEGER NOT NULL DEFAULT 0,
    text_level   INTEGER NOT NULL DEFAULT 0,
    voice_level  INTEGER NOT NULL DEFAULT 0,
    last_message INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS guilds (
    guild_id         TEXT PRIMARY KEY,
    levelup_channel  TEXT,
    card_color       TEXT NOT NULL DEFAULT '#5865F2',
    card_bg_color    TEXT NOT NULL DEFAULT '#23272A',
    card_bar_color   TEXT NOT NULL DEFAULT '#5865F2',
    card_text_color  TEXT NOT NULL DEFAULT '#FFFFFF',
    text_xp_min      INTEGER NOT NULL DEFAULT 15,
    text_xp_max      INTEGER NOT NULL DEFAULT 25,
    voice_xp_rate    INTEGER NOT NULL DEFAULT 10,
    voice_interval   INTEGER NOT NULL DEFAULT 60000,
    xp_multiplier    REAL NOT NULL DEFAULT 1.0,
    ignored_channels TEXT NOT NULL DEFAULT '[]',
    ignored_roles    TEXT NOT NULL DEFAULT '[]',
    no_xp_roles      TEXT NOT NULL DEFAULT '[]'
  );

  CREATE INDEX IF NOT EXISTS idx_text_xp  ON users (guild_id, text_xp  DESC);
  CREATE INDEX IF NOT EXISTS idx_voice_xp ON users (guild_id, voice_xp DESC);
`);

// ─── Prepared Statements ──────────────────────────────────────────────────────

const stmts = {
  getUser: db.prepare(`SELECT * FROM users WHERE guild_id = ? AND user_id = ?`),
  upsertUser: db.prepare(`
    INSERT INTO users (guild_id, user_id, text_xp, voice_xp, text_level, voice_level, last_message)
    VALUES (@guild_id, @user_id, @text_xp, @voice_xp, @text_level, @voice_level, @last_message)
    ON CONFLICT (guild_id, user_id) DO UPDATE SET
      text_xp      = excluded.text_xp,
      voice_xp     = excluded.voice_xp,
      text_level   = excluded.text_level,
      voice_level  = excluded.voice_level,
      last_message = excluded.last_message
  `),
  getGuild:    db.prepare(`SELECT * FROM guilds WHERE guild_id = ?`),
  upsertGuild: db.prepare(`INSERT INTO guilds (guild_id) VALUES (?) ON CONFLICT (guild_id) DO NOTHING`),
  textLeaderboard:  db.prepare(`SELECT user_id, text_xp,  text_level  FROM users WHERE guild_id = ? ORDER BY text_xp  DESC LIMIT 10`),
  voiceLeaderboard: db.prepare(`SELECT user_id, voice_xp, voice_level FROM users WHERE guild_id = ? ORDER BY voice_xp DESC LIMIT 10`),
  textRank:  db.prepare(`SELECT COUNT(*) + 1 AS rank FROM users WHERE guild_id = ? AND text_xp  > (SELECT text_xp  FROM users WHERE guild_id = ? AND user_id = ?)`),
  voiceRank: db.prepare(`SELECT COUNT(*) + 1 AS rank FROM users WHERE guild_id = ? AND voice_xp > (SELECT voice_xp FROM users WHERE guild_id = ? AND user_id = ?)`),
};

// BUG FIX: updateGuild previously interpolated field names directly into SQL — a potential
// injection vector. Now uses an allowlist of valid column names. Any unknown key is ignored.
const GUILD_UPDATABLE_FIELDS = new Set([
  'levelup_channel', 'card_color', 'card_bg_color', 'card_bar_color', 'card_text_color',
  'text_xp_min', 'text_xp_max', 'voice_xp_rate', 'voice_interval',
  'xp_multiplier', 'ignored_channels', 'ignored_roles', 'no_xp_roles',
]);

// ─── XP Formula ───────────────────────────────────────────────────────────────

function xpForLevel(level) {
  return Math.floor(100 * Math.pow(level + 1, 1.5));
}

function totalXpForLevel(level) {
  let total = 0;
  for (let i = 0; i < level; i++) total += xpForLevel(i);
  return total;
}

function levelFromXp(xp) {
  let level = 0, total = 0;
  while (total + xpForLevel(level) <= xp) {
    total += xpForLevel(level);
    level++;
  }
  return level;
}

function xpInCurrentLevel(xp) {
  return xp - totalXpForLevel(levelFromXp(xp));
}

// ─── API ──────────────────────────────────────────────────────────────────────

function getUser(guildId, userId) {
  return stmts.getUser.get(guildId, userId) || {
    guild_id: guildId, user_id: userId,
    text_xp: 0, voice_xp: 0, text_level: 0, voice_level: 0, last_message: 0,
  };
}

function saveUser(user) {
  stmts.upsertUser.run(user);
}

function getGuild(guildId) {
  stmts.upsertGuild.run(guildId);
  return stmts.getGuild.get(guildId);
}

function updateGuild(guildId, fields) {
  getGuild(guildId);
  const safeFields = Object.fromEntries(
    Object.entries(fields).filter(([k]) => GUILD_UPDATABLE_FIELDS.has(k))
  );
  if (Object.keys(safeFields).length === 0) return;
  const sets = Object.keys(safeFields).map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE guilds SET ${sets} WHERE guild_id = @guild_id`)
    .run({ ...safeFields, guild_id: guildId });
}

function getLeaderboard(guildId, type) {
  return type === 'voice'
    ? stmts.voiceLeaderboard.all(guildId)
    : stmts.textLeaderboard.all(guildId);
}

function getRank(guildId, userId, type) {
  if (type === 'voice') return stmts.voiceRank.get(guildId, guildId, userId)?.rank ?? 1;
  return stmts.textRank.get(guildId, guildId, userId)?.rank ?? 1;
}

module.exports = {
  db, getUser, saveUser, getGuild, updateGuild,
  getLeaderboard, getRank,
  xpForLevel, totalXpForLevel, levelFromXp, xpInCurrentLevel,
};
