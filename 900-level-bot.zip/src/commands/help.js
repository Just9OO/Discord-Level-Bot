const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getGuild } = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available commands'),

  async execute(interaction) {
    const settings = getGuild(interaction.guildId);
    const color = settings.card_color || '#5865F2';
    const isAdmin = interaction.member.permissions.has('Administrator');

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('📖 Level Bot — Commands')
      .addFields(
        {
          name: '🌟 User Commands',
          value: [
            '`/level [user]` — View your (or another user\'s) level card',
            '`/leaderboard <text|voice> [duration]` — Server XP rankings',
            '`/stats` — Server-wide XP statistics',
            '`/help` — This message',
          ].join('\n'),
        },
      );

    if (isAdmin) {
      embed.addFields({
        name: '🛡️ Admin Commands',
        value: [
          '`/set-xp <user> <type> <level>` — Force-set a user\'s level',
          '`/set-channel [channel]` — Set level-up announcement channel',
          '`/set-card-color <element> <color>` — Customize card colors',
          '`/set-xp-rate` — Configure XP gain rates & multiplier',
          '`/ignore-channel <channel>` — Toggle XP earning in a channel',
          '`/no-xp-role <role>` — Toggle XP earning for a role',
          '`/reset-user <user> <type>` — Reset a user\'s XP',
        ].join('\n'),
      });
    }

    embed
      .addFields({
        name: '💡 How XP Works',
        value: [
          `**Text XP:** Earned by sending messages (${settings.text_xp_min}–${settings.text_xp_max} XP/message, 60s cooldown)`,
          `**Voice XP:** Earned every minute in a voice channel (+${settings.voice_xp_rate} XP/min)`,
          '**Anti-spam:** Only one message per minute earns XP',
          `**Multiplier:** ${settings.xp_multiplier}× currently active`,
        ].join('\n'),
      })
      .setFooter({ text: 'Levels use an exponential XP curve — higher levels take more effort!' });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
