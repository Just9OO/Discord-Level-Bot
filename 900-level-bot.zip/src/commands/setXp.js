const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const {
  getUser, saveUser, getGuild,
  totalXpForLevel, levelFromXp, xpForLevel,
} = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-xp')
    .setDescription('Set a user\'s level (Admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(opt =>
      opt.setName('user').setDescription('Target user').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('type')
        .setDescription('Text or Voice XP')
        .setRequired(true)
        .addChoices(
          { name: '💬 Text',   value: 'text'  },
          { name: '🎙️ Voice', value: 'voice' },
        )
    )
    .addIntegerOption(opt =>
      opt.setName('level')
        .setDescription('Level to set (0–100)')
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(100)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const type   = interaction.options.getString('type');
    const level  = interaction.options.getInteger('level');
    const guildId = interaction.guildId;

    const userData = getUser(guildId, target.id);
    const xp = totalXpForLevel(level);

    if (type === 'text') {
      userData.text_xp    = xp;
      userData.text_level = level;
    } else {
      userData.voice_xp    = xp;
      userData.voice_level = level;
    }

    saveUser(userData);

    const guildSettings = getGuild(guildId);
    const embed = new EmbedBuilder()
      .setColor(guildSettings.card_color || '#5865F2')
      .setTitle('✅ XP Updated')
      .setDescription(
        `Set **${target.username}**'s ${type === 'voice' ? '🎙️ Voice' : '💬 Text'} level to **${level}**\n` +
        `(${xp.toLocaleString()} total XP)`
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
