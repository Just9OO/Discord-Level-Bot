const { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder } = require('discord.js');
const { getLeaderboard, getGuild } = require('../database/db');
const { generateLeaderboardCard } = require('../utils/cardRenderer');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the server leaderboard')
    .addStringOption(opt =>
      opt.setName('type')
        .setDescription('Text or Voice leaderboard')
        .setRequired(true)
        .addChoices(
          { name: '💬 Text',   value: 'text'  },
          { name: '🎙️ Voice', value: 'voice' },
        )
    )
    .addStringOption(opt =>
      opt.setName('duration')
        .setDescription('Time period (Lifetime only for now; more coming soon)')
        .setRequired(false)
        .addChoices(
          { name: '📅 Day',      value: 'day'      },
          { name: '📆 Week',     value: 'week'     },
          { name: '🗓️ Month',   value: 'month'    },
          { name: '🏆 Lifetime', value: 'lifetime' },
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();

    const type          = interaction.options.getString('type');
    const duration      = interaction.options.getString('duration') || 'lifetime';
    const guildId       = interaction.guildId;
    const guildSettings = getGuild(guildId);

    const entries = getLeaderboard(guildId, type);

    if (entries.length === 0) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(guildSettings.card_color || '#5865F2')
            .setTitle('Leaderboard is empty')
            .setDescription('No one has earned any XP yet — start chatting or jump in a voice channel!'),
        ],
      });
    }

    // BUG FIX: was fetching members one at a time with await inside a for loop (10 serial API calls).
    // Now bulk-fetches all leaderboard user IDs in a single request.
    const userIds = entries.map(e => e.user_id);
    let memberMap = new Map();
    try {
      const fetched = await interaction.guild.members.fetch({ user: userIds });
      for (const [id, member] of fetched) memberMap.set(id, member);
    } catch {
      // If bulk fetch fails, we fall through and use fallback display names
    }

    for (const entry of entries) {
      const member  = memberMap.get(entry.user_id);
      entry.tag     = member?.displayName || `User ${entry.user_id.slice(-4)}`;
      entry.avatarUrl = member?.user.displayAvatarURL({ extension: 'png', size: 64 });
    }

    const buffer     = await generateLeaderboardCard(entries, type, guildSettings);
    const attachment = new AttachmentBuilder(buffer, { name: 'leaderboard.png' });

    const durationLabel = { day: 'Today', week: 'This Week', month: 'This Month', lifetime: 'All Time' }[duration] || 'All Time';

    await interaction.editReply({
      content: `**${durationLabel} ${type === 'voice' ? '🎙️ Voice' : '💬 Text'} Leaderboard**`,
      files:   [attachment],
    });
  },
};
