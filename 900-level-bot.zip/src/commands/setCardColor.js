const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getGuild, updateGuild } = require('../database/db');
const { isValidHex, normalizeColor } = require('../utils/xpHelpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-card-color')
    .setDescription('Customise the level card colors (Admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(opt =>
      opt.setName('element')
        .setDescription('Which part of the card to recolor')
        .setRequired(true)
        .addChoices(
          { name: '🎨 Accent / Border',    value: 'card_color'      },
          { name: '🖼️ Background',          value: 'card_bg_color'   },
          { name: '📊 XP Bar',             value: 'card_bar_color'  },
          { name: '🔤 Text',               value: 'card_text_color' },
        )
    )
    .addStringOption(opt =>
      opt.setName('color')
        .setDescription('Hex color code e.g. #FF5733 or FF5733')
        .setRequired(true)
    ),

  async execute(interaction) {
    const element   = interaction.options.getString('element');
    const rawColor  = interaction.options.getString('color');
    const color     = normalizeColor(rawColor);
    const guildId   = interaction.guildId;

    if (!isValidHex(color)) {
      return interaction.reply({
        content: '❌ Invalid hex color. Use a format like `#FF5733` or `FF5733`.',
        ephemeral: true,
      });
    }

    updateGuild(guildId, { [element]: color });

    const labels = {
      card_color:      'Accent / Border',
      card_bg_color:   'Background',
      card_bar_color:  'XP Bar',
      card_text_color: 'Text',
    };

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('✅ Card Color Updated')
      .setDescription(`**${labels[element]}** color has been set to \`${color}\`.`)
      .addFields({ name: 'Preview', value: `▓▓▓▓▓▓ ${color} ▓▓▓▓▓▓` })
      .setFooter({ text: 'Use /level to preview your new card style!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
