const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { db, getGuild } = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View server-wide XP statistics'),

  async execute(interaction) {
    const guildId  = interaction.guildId;
    const settings = getGuild(guildId);

    const totals = db.prepare(`
      SELECT 
        COUNT(*) AS members,
        SUM(text_xp) AS total_text_xp,
        SUM(voice_xp) AS total_voice_xp,
        MAX(text_level) AS max_text_level,
        MAX(voice_level) AS max_voice_level
      FROM users WHERE guild_id = ?
    `).get(guildId);

    const topText  = db.prepare(`SELECT user_id, text_xp FROM users WHERE guild_id = ? ORDER BY text_xp DESC LIMIT 1`).get(guildId);
    const topVoice = db.prepare(`SELECT user_id, voice_xp FROM users WHERE guild_id = ? ORDER BY voice_xp DESC LIMIT 1`).get(guildId);

    const embed = new EmbedBuilder()
      .setColor(settings.card_color || '#5865F2')
      .setTitle(`📊 ${interaction.guild.name} — XP Stats`)
      .setThumbnail(interaction.guild.iconURL())
      .addFields(
        { name: '👥 Tracked Members', value: `${totals?.members ?? 0}`, inline: true },
        { name: '💬 Total Text XP',   value: `${(totals?.total_text_xp ?? 0).toLocaleString()}`, inline: true },
        { name: '🎙️ Total Voice XP',  value: `${(totals?.total_voice_xp ?? 0).toLocaleString()}`, inline: true },
        { name: '🏅 Highest Text Level',  value: `${totals?.max_text_level ?? 0}`, inline: true },
        { name: '🏅 Highest Voice Level', value: `${totals?.max_voice_level ?? 0}`, inline: true },
        { name: '\u200B', value: '\u200B', inline: true },
      )
      .setFooter({ text: 'Use /leaderboard to see the full rankings!' })
      .setTimestamp();

    if (topText)  embed.addFields({ name: '🥇 Top Text User',  value: `<@${topText.user_id}> — ${topText.text_xp.toLocaleString()} XP`,   inline: true });
    if (topVoice) embed.addFields({ name: '🥇 Top Voice User', value: `<@${topVoice.user_id}> — ${topVoice.voice_xp.toLocaleString()} XP`, inline: true });

    await interaction.reply({ embeds: [embed] });
  },
};
