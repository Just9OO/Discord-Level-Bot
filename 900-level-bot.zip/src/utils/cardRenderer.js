const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const path = require('path');
const { xpForLevel, xpInCurrentLevel } = require('../database/db');

try {
  GlobalFonts.registerFromPath(path.join(__dirname, '../../assets/fonts/Montserrat-Bold.ttf'), 'Montserrat');
  GlobalFonts.registerFromPath(path.join(__dirname, '../../assets/fonts/Montserrat-Regular.ttf'), 'Montserrat');
} catch {
  // Optional — falls back to system fonts
}

const W = 900, H = 280;

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/**
 * BUG FIX: lightenColor previously used parseInt on the raw hex string including '#'.
 * That works for 6-digit hex but gives NaN for shorthand 3-digit hex (#RGB),
 * causing the bar to render black. Now normalises to full 6-digit hex first.
 */
function normaliseHex(hex) {
  const h = hex.replace('#', '');
  // Expand shorthand #RGB → #RRGGBB
  if (h.length === 3) return h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  return h.padStart(6, '0'); // handle any other odd length gracefully
}

function lightenColor(hex, amount) {
  const num = parseInt(normaliseHex(hex), 16);
  const r   = Math.min(255, (num >> 16) + amount);
  const g   = Math.min(255, ((num >> 8) & 0xff) + amount);
  const b   = Math.min(255, (num & 0xff) + amount);
  return `rgb(${r},${g},${b})`;
}

function shiftHue(hex, degrees) {
  const num = parseInt(normaliseHex(hex), 16);
  let r = (num >> 16) / 255;
  let g = ((num >> 8) & 0xff) / 255;
  let b = (num & 0xff) / 255;

  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h, s;
  const l = (max + min) / 2;

  if (max === min) {
    h = s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      default: h = ((r - g) / d + 4) / 6;
    }
  }

  h = (h + degrees / 360) % 1;

  function hue2rgb(p, q, t) {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  }

  const q2 = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p2  = 2 * l - q2;
  const nr  = Math.round(hue2rgb(p2, q2, h + 1 / 3) * 255);
  const ng  = Math.round(hue2rgb(p2, q2, h) * 255);
  const nb  = Math.round(hue2rgb(p2, q2, h - 1 / 3) * 255);
  return `#${((1 << 24) + (nr << 16) + (ng << 8) + nb).toString(16).slice(1)}`;
}

function drawXpBar(ctx, x, y, w, h, progress, barColor, label, level, curXp, maxXp, textColor) {
  const r = h / 2;

  // Track
  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  roundRect(ctx, x, y, w, h, r);
  ctx.fill();

  // Fill
  if (progress > 0) {
    const fillW = Math.max(h, w * Math.min(progress, 1));
    ctx.save();
    roundRect(ctx, x, y, w, h, r);
    ctx.clip();
    const grad = ctx.createLinearGradient(x, 0, x + fillW, 0);
    grad.addColorStop(0, barColor);
    grad.addColorStop(1, lightenColor(barColor, 40));
    ctx.fillStyle = grad;
    ctx.fillRect(x, y, fillW, h);
    ctx.restore();
  }

  // Glow
  if (progress > 0.05) {
    ctx.save();
    ctx.shadowColor = barColor;
    ctx.shadowBlur  = 10;
    roundRect(ctx, x, y, w * Math.min(progress, 1), h, r);
    ctx.fillStyle = 'transparent';
    ctx.fill();
    ctx.restore();
  }

  // Labels
  ctx.fillStyle = textColor;
  ctx.font = 'bold 16px Montserrat, Arial';
  ctx.textAlign = 'left';
  ctx.fillText(label, x, y - 8);

  ctx.font = 'bold 16px Montserrat, Arial';
  ctx.textAlign = 'right';
  ctx.fillText(`LVL ${level}`, x + w, y - 8);

  ctx.font = '13px Montserrat, Arial';
  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  ctx.textAlign = 'right';
  ctx.fillText(`${curXp.toLocaleString()} / ${maxXp.toLocaleString()} XP`, x + w, y + h + 18);
}

async function generateLevelCard(options) {
  const { username, discriminator, avatarUrl, textXp, voiceXp, textLevel, voiceLevel, textRank, voiceRank, guildSettings } = options;

  const bgColor     = guildSettings.card_bg_color  || '#23272A';
  const barColor    = guildSettings.card_bar_color  || '#5865F2';
  const accentColor = guildSettings.card_color      || '#5865F2';
  const textColor   = guildSettings.card_text_color || '#FFFFFF';

  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext('2d');

  // Background
  roundRect(ctx, 0, 0, W, H, 20);
  ctx.fillStyle = bgColor;
  ctx.fill();

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, 'rgba(255,255,255,0.03)');
  bgGrad.addColorStop(1, 'rgba(0,0,0,0.2)');
  ctx.save();
  roundRect(ctx, 0, 0, W, H, 20);
  ctx.clip();
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  const stripe = ctx.createLinearGradient(0, 0, 0, H);
  stripe.addColorStop(0, accentColor);
  stripe.addColorStop(1, 'transparent');
  ctx.fillStyle = stripe;
  ctx.fillRect(0, 0, 5, H);
  ctx.restore();

  // Avatar
  const avatarSize = 110;
  const avatarX = 35, avatarY = H / 2 - avatarSize / 2;

  ctx.save();
  ctx.shadowColor = accentColor;
  ctx.shadowBlur  = 20;
  ctx.beginPath();
  ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2 + 3, 0, Math.PI * 2);
  ctx.strokeStyle = accentColor;
  ctx.lineWidth   = 3;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.beginPath();
  ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
  ctx.clip();
  try {
    const avatar = await loadImage(avatarUrl);
    ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
  } catch {
    ctx.fillStyle = '#555';
    ctx.fillRect(avatarX, avatarY, avatarSize, avatarSize);
  }
  ctx.restore();

  // Username
  const contentX  = avatarX + avatarSize + 25;
  const usernameY = 52;

  ctx.fillStyle = textColor;
  ctx.font      = 'bold 26px Montserrat, Arial';
  ctx.textAlign = 'left';
  ctx.fillText(username, contentX, usernameY);

  if (discriminator && discriminator !== '0') {
    const nameWidth = ctx.measureText(username).width;
    ctx.fillStyle   = 'rgba(255,255,255,0.45)';
    ctx.font        = '18px Montserrat, Arial';
    ctx.fillText(`#${discriminator}`, contentX + nameWidth + 4, usernameY);
  }

  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.font      = '14px Montserrat, Arial';
  ctx.textAlign = 'right';
  ctx.fillText(`Text Rank #${textRank}  ·  Voice Rank #${voiceRank}`, W - 25, usernameY - 10);

  // XP bars
  const barW = W - contentX - 25;
  const barH = 22;

  const textCurXp  = xpInCurrentLevel(textXp);
  const textMaxXp  = xpForLevel(textLevel);
  const textProg   = textMaxXp > 0 ? textCurXp / textMaxXp : 0;

  const voiceCurXp = xpInCurrentLevel(voiceXp);
  const voiceMaxXp = xpForLevel(voiceLevel);
  const voiceProg  = voiceMaxXp > 0 ? voiceCurXp / voiceMaxXp : 0;

  drawXpBar(ctx, contentX, 90,  barW, barH, textProg,  barColor,              '💬 Text',     textLevel,  textCurXp,  textMaxXp,  textColor);
  drawXpBar(ctx, contentX, 185, barW, barH, voiceProg, shiftHue(barColor, 40),'🎙️ Voice', voiceLevel, voiceCurXp, voiceMaxXp, textColor);

  return canvas.encode('png');
}

async function generateLeaderboardCard(entries, type, guildSettings) {
  const bgColor     = guildSettings.card_bg_color  || '#23272A';
  const barColor    = type === 'voice' ? shiftHue(guildSettings.card_bar_color || '#5865F2', 40) : (guildSettings.card_bar_color || '#5865F2');
  const accentColor = guildSettings.card_color      || '#5865F2';
  const textColor   = guildSettings.card_text_color || '#FFFFFF';

  const rowH   = 72;
  const totalH = 80 + entries.length * rowH;
  const canvas = createCanvas(900, totalH);
  const ctx    = canvas.getContext('2d');

  roundRect(ctx, 0, 0, 900, totalH, 20);
  ctx.fillStyle = bgColor;
  ctx.fill();

  ctx.fillStyle = accentColor;
  ctx.font      = 'bold 28px Montserrat, Arial';
  ctx.textAlign = 'left';
  ctx.fillText(`${type === 'voice' ? '🎙️ Voice' : '💬 Text'} Leaderboard`, 30, 48);

  const medals = ['🥇', '🥈', '🥉'];

  for (let i = 0; i < entries.length; i++) {
    const e   = entries[i];
    const y   = 80 + i * rowH;
    const xp  = type === 'voice' ? e.voice_xp  : e.text_xp;
    const lvl = type === 'voice' ? e.voice_level : e.text_level;

    ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.1)';
    roundRect(ctx, 10, y + 2, 880, rowH - 4, 10);
    ctx.fill();

    ctx.font      = 'bold 22px Montserrat, Arial';
    ctx.textAlign = 'left';
    ctx.fillStyle = textColor;
    ctx.fillText(i < 3 ? medals[i] : `#${i + 1}`, 24, y + rowH / 2 + 8);

    ctx.save();
    ctx.beginPath();
    ctx.arc(100, y + rowH / 2, 22, 0, Math.PI * 2);
    ctx.fillStyle = accentColor + '66';
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = textColor;
    ctx.font      = 'bold 18px Montserrat, Arial';
    ctx.textAlign = 'left';
    ctx.fillText(e.tag || `User ${e.user_id.slice(-4)}`, 135, y + rowH / 2 + 6);

    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.font      = '15px Montserrat, Arial';
    ctx.textAlign = 'right';
    ctx.fillText(`Level ${lvl}  ·  ${xp.toLocaleString()} XP`, 875, y + rowH / 2 + 6);

    const curXp = xpInCurrentLevel(xp);
    const maxXp = xpForLevel(lvl);
    const prog  = maxXp > 0 ? curXp / maxXp : 0;
    const barX  = 135, barY = y + rowH - 18, barW = 720, barH2 = 6;

    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    roundRect(ctx, barX, barY, barW, barH2, 3);
    ctx.fill();

    if (prog > 0) {
      ctx.fillStyle = barColor;
      roundRect(ctx, barX, barY, barW * Math.min(prog, 1), barH2, 3);
      ctx.fill();
    }
  }

  return canvas.encode('png');
}

module.exports = { generateLevelCard, generateLeaderboardCard };
