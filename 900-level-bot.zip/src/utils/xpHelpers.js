/**
 * Validates a hex color code
 */
function isValidHex(color) {
  return /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(color);
}

/**
 * Clamp a number between min and max
 */
function clamp(val, min, max) {
  return Math.min(Math.max(val, min), max);
}

/**
 * Returns XP needed to exactly reach a given level from 0
 */
function totalXpForLevel(level, { getDb } = {}) {
  const { totalXpForLevel: _total } = require('../database/db');
  return _total(level);
}

/**
 * Normalise a color input — accepts #RGB, #RRGGBB, or "RRGGBB" (adds #)
 */
function normalizeColor(input) {
  const str = input.trim();
  if (str.startsWith('#')) return str;
  return '#' + str;
}

/**
 * Format a duration for display
 */
function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

module.exports = { isValidHex, clamp, normalizeColor, formatDuration };
